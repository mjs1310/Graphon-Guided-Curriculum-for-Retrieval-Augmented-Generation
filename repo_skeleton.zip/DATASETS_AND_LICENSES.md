# DATASETS_AND_LICENSES.md

- **Cora**: Research-only; cite Sen et al., AIJ 2008. Verify license of the distribution you use (Planetoid/PyG).
- **NQ-Open**: Follow Google terms; add link and citation.
- **TRUE-style set**: Add exact benchmark link and license.
- **Models/Embeddings**: List each model with license.

Replace placeholders with exact links and license texts before release.
